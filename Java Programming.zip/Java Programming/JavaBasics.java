import java.util.*;

public class JavaBasics{

  public static void binaryToDec(int n){
    int num = n;
    int pow = 0;
    int decimal = 0;
    while(n>0){
      int last = n%10;
      decimal += last * Math.pow(2,pow);
      pow++;
      n = n/10;
    }

    System.out.println("Decimal of binary number " + num + " is " + decimal);
  }

  public static void decToBin(int n){
    int num = n;
    int pow = 0;
    int binary = 0;
    while(n>0){
      int rem = n%2;
      binary += rem * Math.pow(10,pow);
      pow++;
      n = n/2;
    }

    System.out.println("Binary of Decimal number " + num + " is " + binary);
  } 

  public static void hollowRect(int rows, int cols){
    for(int i = 0; i<rows; i++){
      for(int j = 0; j<cols; j++){
        if(i == 0 || i == rows-1 || j == 0 || j == cols-1){
          System.out.print("*");
        }else{
          System.out.print(" ");
        }
      }
      System.out.println();
    }
  }

  public static void ivertedHalfPyramid(int n){
    for(int i = 0; i<n; i++){
      for(int j = 0; j<n; j++){
        if(j<n-i-1){
          System.out.print(" ");
        }else{
          System.out.print("*");
        }
      }
      System.out.println();
    }
  }

  public static void invertedHalfNum(int n){
    for(int i = 0; i<n; i++){
      for(int j = 0; j<n-i; j++){
        System.out.print(j+1);
      }
      System.out.println();
    }
  }

  public static void floydTri(int n){
    int a = 1;
    for(int i = 0; i<n; i++){
      for(int j = 0; j<=i; j++){
        System.out.print(a++ + " ");
      }
      System.out.println();
    }
  }

  public static void one_zero(int n){
    for(int i = 1; i<=n; i++){
      for(int j = 1; j<=i; j++){
        if((i+j)%2 == 0){
          System.out.print(1);
        }else{
          System.out.print(0);
        }
      }
      System.out.println();
    }
  }

  public static void butterfly(int n){
    for(int i = 1; i<=n; i++){
      for(int j = 1; j<=i; j++){
        System.out.print("*");
      }

      for(int j = 1; j<=2*(n-i); j++){
        System.out.print(" ");
      }

      for(int j = 1; j<=i; j++){
        System.out.print("*");
      }
      System.out.println();
    }

    for(int i = n; i>=1; i--){
      for(int j = 1; j<=i; j++){
        System.out.print("*");
      }

      for(int j = 1; j<=2*(n-i); j++){
        System.out.print(" ");
      }

      for(int j = 1; j<=i; j++){
        System.out.print("*");
      }
      System.out.println();
    }
    
  }

  public static void rhombus(int n){
    for(int i = 1; i<=n; i++){
      for(int j = 1; j<=n-i; j++){
        System.out.print(" ");
      }
      
      for(int j = 1; j<=n; j++){
        System.out.print("*");
      }
      System.out.println();
    }
  }

  public static void diamond(int n){
    for(int i = 1; i<=n; i++){
      for(int j = 1; j<=n-i; j++){
        System.out.print(" ");
      }

      for(int j = 1; j<=(2*i)-1; j++){
        System.out.print("*");
      }

      System.out.println();
    }

    for(int i = n; i>=1; i--){
      for(int j = 1; j<=n-i; j++){
        System.out.print(" ");
      }

      for(int j = 1; j<=(2*i)-1; j++){
        System.out.print("*");
      }

      System.out.println();
    }
  }

  public static void main(String args[]){
    diamond(5);
    
  }
}