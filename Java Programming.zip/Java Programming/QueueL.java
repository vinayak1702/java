public class QueueL {
    static class Node{
        int data;
        Node next;

        Node(int data){
            this.data = data;
            this.next = null;
        }
    }

    static class Queue{
        static Node head = null;
        static Node tail = null;

        public static boolean isEmpty(){
            return head == null && tail == null;
        }

        public static void add(int data){
            Node newNode = new Node(data);
            if(head == null){
                head = tail = newNode;
                return;
            }

            tail.next = newNode;
            tail = newNode;
        }

        public static int remove(){
            if(isEmpty()){
                System.out.println("Empty Queue!");
                return -1;
            }

            int result = head.data;
            if(tail == head){
                tail = head = null;
            }else{
                head = head.next;
            }
            
            return result;
        }

        public static int peek(){
            if(isEmpty()){
                System.out.println("Empty Queue!");
                return -1;
            }

            return head.data;
        }

    }

    public static void printNonRepeating(String str){
        int freq[] = new int[26]; // a - z
        Queue<Character> q = new LinkedList<>();

        for(int i = 0; i < str.length(); i++){
            char ch = str.charAt(i);
            q.add(ch);
            freq[ch - 'a']++;

            while(!q.isEmpty && freq[q.peek() - 'a'] > 1){
                q.remove();
            }

            if(q.isEmpty()){
                System.out.print(-1 + " ");
            }else{
                System.out.print(q.peek() + " ");
            }
        }
        System.out.println();
    }
    public static void main(String[] args) {
        String str = "aabccxb";
        // printNonRepeating(str);
    }
    
}
