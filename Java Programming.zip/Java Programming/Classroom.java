import java.util.ArrayList;

public class Classroom {
    public static void changeArr(int arr[], int i, int val){
        if(i == arr.length){
            printArr(arr);
            return;
        }

        arr[i] = val;
        changeArr(arr, i+1, val+1);
        arr[i] = arr[i] - 2;
    }

    public static void printArr(int arr[]){
        for(int i = 0; i<arr.length; i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public static void findSubsets(String str, String ans, int i){
        //base case 
        if(i == str.length()){
            System.out.println(ans);
            return;
        }

        //recursion
        //Yes choice
        findSubsets(str, ans+str.charAt(i), i+1);

        //No choice
        findSubsets(str, ans, i+1);
    }

    public static void findPermutation(String str, String ans){
        // base
        if(str.length() == 0){
            System.out.println(ans);
            return;
        }
        // recursion
        for(int i = 0; i<str.length(); i++){
            char curr = str.charAt(i);
            String newStr = str.substring(0, i) + str.substring(i+1);
            findPermutation(newStr, ans+curr);
        }

    }

    public static boolean isSafe(char board[][], int row, int col){
        // vertical up
        for(int i = row-1; i>=0; i--){
            if(board[i][col] == 'Q'){
                return false;
            }
        }

        // diagonal left up
        for(int i = row-1, j = col-1; i>=0 && j>=0; i--,j--){
            if(board[i][j] == 'Q'){
                return false;
            }
        }

        // diagonal right up
        for(int i = row-1, j = col+1; i>=0 && j<board.length; i--,j++){
            if(board[i][j] == 'Q'){
                return false;
            }
        }

        return true;
    }

    public static void nQueens(char board[][], int row){
        //base
        if(row == board.length){
            // printBoard(board);
            count++;
            return;
        }

        //column loop
        for(int j = 0; j<board.length; j++){
            if(isSafe(board,row,j)){
                board[row][j] = 'Q';
                nQueens(board, row+1); //function call
                board[row][j] = 'x'; //backtracking step
            }
            
        }
        
    }

    public static void printBoard(char board[][]){
        System.out.println("------------Chess Board------------");
        for(int i = 0; i<board.length; i++){
            for(int j = 0; j<board.length; j++){
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    static int count = 0;

    public static int gridWays(int i, int j, int n, int m){
        // base case
        if(i == n-1 && j == m-1){ // condition for last cell
            return 1;
        }else if(i == n || j == m){// condition for out of boundary
            return 0;
        }

        int w1 = gridWays(i+1, j, n, m);
        int w2 = gridWays(i, j+1, n, m);
        return w1 + w2;
    }

    public static boolean isSafe2(int sudoku[][], int row, int col, int digit){
        //column
        for(int i = 0; i<=8; i++){
            if(sudoku[i][col] == digit){
                return false;
            }
        }

        //row 
        for(int j = 0; j<=8; j++){
            if(sudoku[row][j] == digit){
                return false;
            }
        }

        //grid
        int sr = (row/3)*3;
        int sc = (col/3)*3;

        for(int i = sr; i<sr+3; i++){
            for(int j = sc; j<sc+3; j++){
                if(sudoku[i][j] == digit){
                    return false;
                }
            }
        }

        return true;
    }

    public static boolean sudokuSolver(int sudoku[][], int row, int col){
        //base cas
        if(row == 9){
            return true;
        }

        //recursion 
        int nextRow = row, nextCol = col+1;
        if(col+1 == 9){
            nextRow = row+1;
            nextCol = 0;
        }

        if(sudoku[row][col] != 0){
            return sudokuSolver(sudoku, nextRow, nextCol);
        }

        for(int digit = 1; digit<=9; digit++){
            if(isSafe2(sudoku, row, col, digit)){
                sudoku[row][col] = digit;
                if(sudokuSolver(sudoku, nextRow, nextCol)){
                    return true;
                }
                sudoku[row][col] = 0;
            }
        }
        
        return false;
    }

    public static void printSudoku(int sudoku[][]){
        for(int i = 0; i<9; i++){
            for(int j = 0; j<9; j++){
                System.out.print(sudoku[i][j] + " ");
            }
            System.out.println();
        }
    }

    // public static int storeWater(ArrayList<Integer> height){
    //     int maxWater = 0;
        
    //     //brute force
    //     for(int i = 0; i<height.size(); i++){
    //         for(int j = i+1; j<height.size(); j++){
    //             int ht = Math.min(height.get(i), height.get(j));
    //             int width = j-i;
    //             int currWater = ht * width;
    //             maxWater = Math.max(currWater, maxWater);
    //         }
    //     }

    //     return maxWater;
    // }

    // 2 pointer approach
    public static int storeWater(ArrayList<Integer> height){
        int maxWater = 0;
        int lp = 0;
        int rp = height.size() - 1;

        while(lp < rp){
            int ht = Math.min(height.get(lp), height.get(rp));
            int width = rp - lp;
            int currWater = ht * width;
            maxWater = Math.max(maxWater, currWater);

            // update ptr
            if(height.get(lp) < height.get(rp)){
                lp++;
            }else{
                rp--;
            }
        }

        return maxWater;
    }

    public static boolean pairSum1(ArrayList<Integer> list, int target){
        int lp = 0;
        int rp = list.size()-1;

        while(lp < rp){
            if(list.get(lp) + list.get(rp) == target){
                return true;
            }
            
            if(list.get(lp) + list.get(rp) < target){
                lp++;
            }else{
                rp--;
            }
        }

        return false;
    }

    public static boolean pairSum2(ArrayList<Integer> list, int target){
        int bp = -1; // pivot
        int n = list.size();

        for(int i = 0; i<list.size(); i++){
            if(list.get(i)>list.get(i+1)){ // breaking point
                bp = i;
                break;
            }
        }

        int lp = bp + 1; // smallest
        int rp = bp; // largest

        while(lp != rp){
            //case 1
            if(list.get(lp) + list.get(rp) == target){
                return true;
            }

            //case 2
            if(list.get(lp) + list.get(rp) < target){
                lp = (lp + 1) % n;
            }else{
                //case 3
                rp = (n + rp - 1) % n;
            }
        }

        return false;
    }

    public static void main(String args[]){
        ArrayList<Integer> list = new ArrayList<>();
        list.add(11);
        list.add(15);
        list.add(6);
        list.add(8);
        list.add(9);
        list.add(10);
        int target = 100;

        System.out.println(pairSum2(list, target));


    //     int sudoku[][] = {{0, 0, 8, 0, 0, 0, 0, 0, 0},
    //                     {4, 9, 0, 1, 5, 7, 0, 0, 2},
    //                     {0, 0, 3, 0, 0, 4, 1, 9, 0},
    //                     {1, 8, 5, 0, 6, 0, 0, 2, 0},
    //                     {0, 0, 0, 0, 2, 0, 0, 6, 0},
    //                     {9, 6, 0, 4, 0, 5, 3, 0, 0},
    //                     {0, 3, 0, 0, 7, 2, 0, 0, 4},
    //                     {0, 4, 9, 0, 3, 0, 0, 5, 7},
    //                     {8, 2, 7, 0, 0, 9, 0, 1, 3}};
    //    if(sudokuSolver(sudoku, 0, 0)){
    //         System.out.println("Solution Exists!");
    //         printSudoku(sudoku);
    //     }else{
    //         System.out.println("Solution does not exist!");
    //     }
    }
  
}
