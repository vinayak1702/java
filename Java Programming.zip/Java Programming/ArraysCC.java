import java.util.*;

public class ArraysCC{
    public static int binarySearch(int arr[], int key){
        int start = 0;
        int end = arr.length-1;

        while(start<=end){
            int mid = (start + end)/2;

            if(key == arr[mid]){
                return mid;
            }else if(arr[mid] < key){
                start = mid + 1;
            }else{
                end = mid - 1;
            }
        }
        return -1;
    }

    public static void reverse(int arr[]){
        int first = 0 , last = arr.length-1;

        while(first<last){
            int temp = arr[last];
            arr[last] = arr[first];
            arr[first] = temp;

            first++;
            last--;
        }
    }

    public static void pairs(int arr[]){
        for(int i = 0; i<arr.length; i++){
            for(int j = i+1; j<arr.length; j++){
                System.out.print("("  + arr[i] + "," + arr[j] + ")");
            }
            System.out.println();
        }
    }

    public static void subArray(int arr[]){
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;

        for(int i = 0; i<arr.length; i++){
            for(int j = i; j<arr.length; j++){
                currSum = 0;
                for(int k = i; k<=j; k++){
                    // System.out.print(arr[k] + " ");
                    currSum += arr[k];
                }
                System.out.println(currSum);
                if(maxSum < currSum){
                    maxSum = currSum;
                }
            }
            // System.out.println();
        }
        System.out.println("Max sum " + maxSum);
    }

    public static void kadanes(int arr[]){
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;

        for(int i = 0;i<arr.length;i++){
            currSum += arr[i];
            if(currSum < 0){
                currSum = 0;
            }
            maxSum = Math.max(currSum,maxSum);
        }

        System.out.println("Max sum is " + maxSum);
    }

    public static void rainWater(int arr[]){
        int left[] = new int[arr.length];
        left[0] = arr[0];

        for(int i = 1; i<arr.length; i++){
            left[i] = Math.max(arr[i],left[i-1]);

            // if(i == 0){
            //     left[0] = arr[0];
            // }else if(arr[i]>left[i-1]){
            //     left[i] = arr[i];
            // }else{
            //     left[i] = left[i-1];
            // }
        }

        int right[] = new int[arr.length];
        right[arr.length-1] = arr[arr.length-1];

        for(int i = arr.length-2; i>=0; i--){
            right[i] = Math.max(arr[i], right[i+1]);

            // if(i == arr.length-1){
            //     right[arr.length-1] = arr[arr.length-1];
            // }else if(arr[i]>right[i+1]){
            //     right[i] = arr[i];
            // }else{
            //     right[i] = right[i+1];
            // }
        }

        int trappedWater = 0;
        int waterLevel = 0;
        int height = 0;

        for(int i = 0;i<arr.length; i++){
            waterLevel = Math.min(left[i],right[i]);
            height = arr[i];
            trappedWater += waterLevel - height;
        }

        System.out.println("Water level is " + trappedWater);
    }

    public static int buyAndSellStock(int arr[]){
        int buyingPrice = Integer.MAX_VALUE;
        int maxProfit = 0;
        //sellingPrice = arr[i]

        for(int i = 0; i<arr.length; i++){
            if(buyingPrice < arr[i]){
                int profit = arr[i] - buyingPrice;
                maxProfit = Math.max(maxProfit,profit);
            }else{
                buyingPrice = arr[i];
            }
        }

        return maxProfit;
    }

    public static void sumZero(int arr[]){
        for(int i = 0; i<arr.length; i++){
            for(int j = i+1; j<arr.length; j++){
                for(int k = j+1; j<arr.length; k++){
                    if(arr[i] + arr[j] + arr[k] == 0){
                        System.out.println(i + " " + j + " " + k);
                    }
                }
            }
        }
    }

    public static int minimum(int arr[]){
        int n = arr.length;
        int left = 0;
        int right = n-1;
        int mid = left + (right - left)/2;
        while(left<right){
            if(arr[mid-1]>arr[mid]){
                return mid;
            }else if(left[mid-1]<arr[mid] && arr[right]>arr[mid]){
                left = mid+1;
            }else{
                right = mid-1;
            }
        }
    }

    public static void main(String args[]){
        // int arr[] = {-2,-3,4,-1,-2,1,5,-3};
        int arr[] = {-1,0,1,2,-1,-4};
        System.out.println(buyAndSellStock(arr));
        
        

        // for(int i = 0; i<arr.length; i++){
        //     System.out.print(arr[i] + " ");
        // }


    }
}