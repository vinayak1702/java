public class OOPS{
    public static void main(String args[]){
        Horse h = new Horse();
        System.out.println(h.color);
    }
}

class Animal{
    String color;
    Animal(){
        System.out.println("Animal class constructor!");
    }
}

class Horse extends Animal{
    Horse(){
        //super()   by default it is called by java 
        super.color = "Black";
        System.out.println("Horse constructor!");
    }
}

interface Herbivore{
    void veg();
}

interface Carnivore{
    void nonVeg();
}

class Omnivore implements Herbivore,Carnivore{
    public void veg(){
        System.out.println("Eats veg");
    }

    public void nonVeg(){
        System.out.println("Eats non-veg");
    }

}

interface ChessPlayer{
    void moves();
}

class Queen implements ChessPlayer{
    public void moves(){
        System.out.println("Up, Down, Left, Right, Diagonal(in all 4 directions)");
    }
}

class Rook implements ChessPlayer{
    public void moves(){
        System.out.println("Up, Down, Left, Right");
    }
}

class King implements ChessPlayer{
    public void moves(){
        System.out.println("Up, Down, Left, Right, Diagonal(in all 4 directions by 1 step)");
    }
}

class Pen{
    String color;
    int tip;

    void setColor(String newColor){
        color = newColor;
    }

    void setTip(int newTip){
        tip = newTip;
    }
}