import java.lang.reflect.Array;
import java.util.*;
import java.util.LinkedList;

import javax.swing.plaf.TextUI;

class Practice{
    static class Edge{
        int src;
        int dest;
        // int wt;

        public Edge(int s, int d){
            this.src = s;
            this.dest = d;
            // this.wt = w;
        }
    }

    public static void createGraph(ArrayList<Edge> graph[]){
        for(int i = 0; i < graph.length; i++){
            graph[i] = new ArrayList<>();
        }

        graph[0].add(new Edge(0, 1));
        graph[1].add(new Edge(1, 2));
        graph[2].add(new Edge(2, 3));
        graph[2].add(new Edge(2, 4));   
        graph[3].add(new Edge(3, 4));
        // graph[4].add(new Edge(4, 3));
    }

    public static boolean isCycle(ArrayList<Edge> graph[]){
        boolean vis[] = new boolean[graph.length];
        boolean stack[] = new boolean[graph.length];
        for(int i = 0; i < graph.length; i++){
            if(!vis[i]){
                if(isCycleUtil(graph, i, vis, stack)){
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isCycleUtil(ArrayList<Edge> graph[], int curr, boolean vis[], boolean stack[]){
        vis[curr] = true;
        stack[curr] = true;

        for(int i = 0; i < graph[curr].size(); i++){
            Edge e = graph[curr].get(i);
            if(stack[e.dest]){
                return true;
            }else if(!vis[e.dest] && isCycleUtil(graph, e.dest, vis, stack)){
                return true;
            }
        }
        stack[curr] = false;
        return false;
    }
    
    public static int fact(int n){
        if(n == 0 || n == 1){
            return 1;
        }

        int a = fact(n - 1);
        return n * a;
    }

    static int a = 0;
    public static void towerOfHanoi(int n, String src, String helper, String dest, int num, String p) {
        if (n == 1) {
            System.out.println("Transfer disk " + n + " from " + src + " to " + dest);
        } else {
            if(dest == p && num == n){
                a++;
            }
            towerOfHanoi(n - 1, src, dest, helper, num, p);
            System.out.println("Transfer disk " + n + " from " + src + " to " + dest);
            towerOfHanoi(n - 1, helper, src, dest, num, p);
        }
    }   

    public static void path(int arr[][], int i, int j, String str){
        if(i < 0 || i >= arr.length || j < 0 || j >= arr[0].length || arr[i][j] == 1){
            return;
        }

        if(i == arr.length - 1 && j == arr[0].length - 1){
            System.out.println(str);
            // return;
        }
        arr[i][j] = 1;
        path(arr, i + 1, j, str + "D");
        path(arr, i - 1, j, str + "U");
        path(arr, i, j + 1, str + "R");
        path(arr, i, j - 1, str + "L");
        arr[i][j] = 0;
    }

    public static ArrayList<Integer> arrayList = new ArrayList<>();


    // public static void printPath(ArrayList<Edge> graph[], int src, int dest, boolean vis[]){
    //     if(src == dest){
    //         arrayList.add(src);
    //         System.out.println(arrayList);
    //         arrayList.remove(arrayList.size() - 1);
    //     }
    //     vis[src] = true;
    //     arrayList.add(src);
    //     for(int i = 0; i < graph[src].size(); i++){
    //         Edge e = graph[src].get(i);
    //         if(!vis[e.dest]){
    //             printPath(graph, e.dest, dest, vis);
    //         }else{
    //             if(e.dest == dest){
    //                 arrayList.add(e.dest);
    //                 System.out.println(arrayList);
    //                 arrayList.remove(arrayList.size() - 1);
    //             }
    //         }
    //     }
    //     arrayList.remove(arrayList.size() - 1);
    // }

    public static void printPath(ArrayList<Edge> graph[], int src, int dest, boolean vis[], boolean stack[]){
        if(src == dest){
            arrayList.add(src);
            System.out.println(arrayList);
            arrayList.remove(arrayList.size() - 1);
        }
        vis[src] = true;
        stack[src] = true;
        arrayList.add(src);
        for(int i = 0; i < graph[src].size(); i++){
            Edge e = graph[src].get(i);
            if(!stack[e.dest]){
                printPath(graph, e.dest, dest, vis,stack);
            }
        }
        stack[src] = false;
        arrayList.remove(arrayList.size() - 1);
    }

    public static void main(String args[]){
        int arr[] = {1, 4, 3, 2, 9, 0, 13};
        for(int i = 1; i < arr.length; i++){
            int j = i - 1;
            int curr = arr[i];
            while(j >= 0 && curr < arr[j]){
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = curr;
        }

        // for(int i = 0; i < arr.length; i++){
        //     System.out.println(arr[i]);
        // }

        System.out.println(7 / 2);

    }
}




