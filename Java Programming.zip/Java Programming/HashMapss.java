import java.util.*;

public class HashMapss {
    public static boolean isAnagram(String s, String t){
        if(s.length() != t.length()){
            return false;
        }
        HashMap<Character, Integer> map = new HashMap<>();

        for(int i = 0; i < s.length(); i++){
            map.put(s.charAt(i), map.getOrDefault(s.charAt(i), 0) + 1);
        }

        for(int i = 0; i < t.length(); i++){
            char ch = t.charAt(i);
            if(map.get(ch) != null){
                if(map.get(ch) == 1){
                    map.remove(ch);
                }else{
                    map.put(ch, map.get(ch) - 1);
                }
            }else{
                return false;
            }
        }
        return map.isEmpty();

    }
    public static void main(String[] args) {
        // Valid Anagram
        String s = "tulip";
        String t = "lipid";
        System.out.println(isAnagram(s, t));

        // // Majority element
        // int arr[] = {1, 3, 2, 5, 1, 3, 1, 5, 1};
        // HashMap<Integer, Integer> map = new HashMap<>();

        // for(int i = 0; i < arr.length; i++){
        //     int num = arr[i];
        //     map.put(num, map.getOrDefault(num, 0) + 1);
        //     // if(map.containsKey(num)){
        //     //     map.put(num, map.get(num) + 1);
        //     // }else{
        //     //     map.put(num, 1);
        //     // }
        // }

        // // Set<Integer> keySet = map.keySet();
        // for (Integer key : map.keySet()) {
        //     if(map.get(key) > arr.length / 3){
        //         System.out.println(key);
        //     }
        // }
    }
}
 