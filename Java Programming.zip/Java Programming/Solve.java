import java.util.*;

class Solve {
  public static int simpleSum(int a, int b, int c) {
    // write the logic here
    return a + b + c;
  }

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int A = scanner.nextInt();
    int B = scanner.nextInt();
    int C = scanner.nextInt();


    System.out.println(simpleSum(A, B, C));
  }
}