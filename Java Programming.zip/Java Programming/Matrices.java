import java.util.*;

public class Matrices{
    public static boolean search(int arr[][],int key){
        for(int i = 0; i<arr.length; i++){
            for(int j = 0; j<arr[0].length; j++){
                if(arr[i][j] == key){
                    System.out.println("Key found at " + i + "," + j);
                    return true;
                    
                }
            }
        }
        System.out.println("Key not found!");
        return false;
    }

    public static void spiral(int arr[][]){
        int startRow = 0;
        int startCol = 0;
        int endRow = arr.length - 1;
        int endCol = arr[0].length-1;

        while(startRow <= endRow && startCol <= endCol){
            // i = row , j = col

            //top
            for(int j = startCol; j <= endCol; j++){
                System.out.print(arr[startRow][j] + " ");
            }

            //right
            for(int i = startRow+1; i <= endRow; i++){
                System.out.print(arr[i][endCol] + " ");
            }

            //bottom
            for(int j = endCol-1; j >= startCol; j--){
                if(startRow == endRow){
                    return;
                }
                System.out.print(arr[endRow][j] + " ");
            }

            //left
            for(int i = endRow-1; i >= startRow+1; i--){
                if(startCol == endCol){
                    return;
                }
                System.out.print(arr[i][startCol] + " ");
            }

            startRow++;
            startCol++;
            endRow--;
            endCol--;
        }
        System.out.println();
    }

    public static int diagonalSum(int arr[][]){
        
        // for(int i = 0; i<arr.length; i++){
        //     for(int j = 0; j<arr[0].length; j++){
        //         if(i == j){
        //             sum += arr[i][j];
        //         }else if(i+j == arr.length - 1){
        //             sum += arr[i][j];
        //         }
        //     }
        // }

        int sum = 0;
        for(int i = 0; i<arr.length; i++){
            sum += arr[i][i];
            if(i != arr.length - 1 - i){
                sum += arr[i][arr.length - 1 - i];
            }
        }
        return sum;
    }

    public static boolean staircaseSearch(int arr[][], int key){
        int row = 0, col = arr[0].length-1;

        while(row < arr.length && col >= 0){
            if(arr[row][col] == key){
                System.out.println("Key found at " + row + "," + col);
                return true;
            }else if(key < arr[row][col]){
                col--;
            }else{
                row++;
            }
        }
        System.out.println("Key not found!!");
        return false;
    }

    public static void main(String args[]){
        int matrix[][] = {{10,20,30,40},
                          {15,25,35,45},
                          {27,29,37,48},
                          {32,33,39,50}};
        
        int key = 100;

        staircaseSearch(matrix,key);
        // int matrix[][] = new int[15][15];
        // int n = matrix.length, m = matrix[0].length;
        // Scanner s = new Scanner(System.in);

        // for(int i = 0; i<n; i++){
        //     for(int j = 0; j<m; j++){
        //         matrix[i][j] = s.nextInt();
        //     }
        // }

        // for(int i = 0; i<n; i++){
        //     for(int j = 0; j<m; j++){    
        //         System.out.print(matrix[i][j] + " ");
        //     }
        //     System.out.println();
        // }

        // spiral(matrix);

        // System.out.println(diagonalSum(matrix));
    }
}